#ifndef CLIENTE
#define CLIENTE

class Cliente{
public:
	int numCliente;
	int instanteEntrada;
	int tempoAtendimento;
};

#endif

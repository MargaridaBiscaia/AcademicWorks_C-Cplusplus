#include "evento.hpp"
#include "cliente.hpp"

#include <cstdlib>
#include <iostream>
#include <queue> 
#include <cmath>
#include <ctime>
#include <random>

using namespace std;

//NumAleatorio
int Evento::NumAleatorio (){
	double u;
	float miu,x;
		
	miu = 1 / Lambda ;  
		
	u = (double) rand() / ((double) RAND_MAX +1); // ajustar o valor para (0,1)
		
	x = -log(1-u)*miu;
		
	return (x);
}
	
// ExecutaSimulacao
void Evento::ExecutaSimulacao(FILE *f1) {
	// inicializar as variáveis a 0
	cliente = NULL;
	numeroClientes = 0; 
	numeroAtendidos = 0;
	somaTemposEspera = 0;
	somaComprimentos = 0;
	
	for (tempo = 0; tempo < DuracaoDaSimulacao; tempo++) { // durante o tempo da simulação
		if(NumAleatorio() < Lambda) // gerar um número aleatório para entrada de cliente
			{ColocaClienteNaFila(f1);} // colocar o cliente na fila
		
		ProcessaFila(f1);
	}
}

// ColocaClienteNaFila
void Evento::ColocaClienteNaFila(FILE *f1) {
	Cliente c;
		   
	numeroClientes++;
		   
	c.numCliente = numeroClientes;
	c.instanteEntrada = tempo;
		   
	c.tempoAtendimento = NumAleatorio();

	f.push(c); // colocar cliente na fila

	fprintf(f1,"Segundo %.0f: Cliente %d entra na fila\n", tempo,numeroClientes);
	  
}
	
// AtendeCliente
void Evento::AtendeCliente(FILE *f1) {
	Cliente *c; //ponteiro auxiliar
	   
	*c = f.front(); 
	cliente = c; // cliente atendido passa a ser o primeiro da fila
	f.pop(); // tira o primeiro cliente da fila
		   
	numeroAtendidos++;

	somaTemposEspera = somaTemposEspera + (tempo - c->instanteEntrada);
	fprintf(f1,"Segundo %.0f: Cliente %d entra na caixa\n", tempo,c->numCliente);
	
}

// DispensaCliente
void Evento::DispensaCliente(FILE *f1) {
	fprintf(f1,"Segundo %.0f: Cliente %d deixa a caixa\n", tempo,cliente->numCliente);
	   
	cliente= NULL; // nenhum cliente a ser atendido
}

// ProcessaFila
void Evento::ProcessaFila(FILE *f1) {
		
	if (cliente == NULL) {
		if (f.empty()==0) 
			{AtendeCliente(f1);} // se não houver cliente na caixa e a fila não estiver vazia atender o cliente
	} 
	else {
		if (cliente->tempoAtendimento == 0) 
			{DispensaCliente(f1);} // tempo de atendimento a 0 então dispensa-se o cliente
		else
			{cliente->tempoAtendimento--;} // diminui tempo de atendimento
	}
	   
	somaComprimentos = somaComprimentos + f.size();
}
	
// VerNumAtendidos
int Evento::VerNumAtendidos(){
	return (numeroAtendidos);
}
	
// VerSomaTemposEspera
int Evento::VerSomaTemposEspera(){
	return (somaTemposEspera);
}
	
// VerSomaComprimentos
int Evento::VerSomaComprimentos(){
	return (somaComprimentos);
}



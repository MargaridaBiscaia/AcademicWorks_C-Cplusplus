#include "cliente.hpp"
#include "evento.hpp"
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <queue> 

using namespace std;

int main( ) {
	FILE *f;
	Evento dados;
	
	f=fopen("dados.csv","w");
	
	srand(time(NULL)); // para gerar números diferentes
	
	dados.ExecutaSimulacao(f);
	
	fclose(f);
  
	cout << "\t Resultados da simulação para uma caixa" << endl;
	cout << "Duração da Simulação: " << (int) DuracaoDaSimulacao << endl;
	cout << "ProbabilidadeDeEntrada: " << (double) Lambda << endl;
	cout << "Clientes atendidos: " << dados.VerNumAtendidos() << endl;
	cout << "Tempo médio de espera: " << (double) dados.VerSomaTemposEspera() / dados.VerNumAtendidos() << endl;
	cout << "Comprimento médio da fila: " << (double) dados.VerSomaComprimentos() / DuracaoDaSimulacao << endl;
	
	return 0;
}


#ifndef EVENTO
#define EVENTO

#define DuracaoDaSimulacao 5040
#define Lambda 0.05 

#include "cliente.hpp"
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <queue>

using namespace std; 

class Evento{
private:

	queue<Cliente> f;
	Cliente *cliente; // ponteiro para o cliente que está a ser atendido
	float tempo;
	int numeroClientes;
	int numeroAtendidos;
	int somaTemposEspera;
	int somaComprimentos;
	
public:	

	/* NumAleatorio - gera um número aleatório x com uma distribuição 
	 * exponencial negativa de média miu */
	int NumAleatorio ();
	
	/* ExecutaSimulacao - inicializar as variáveis a zero e executar a simulação */
	void ExecutaSimulacao (FILE *);
	
	/* ColocaCLienteNaFila - coloca um cliente na fila */
	void ColocaClienteNaFila (FILE *);
	
	/* AtendeCliente - atende o primeiro cliente da fila */
	void AtendeCliente (FILE *); 
	
	/* DispensaCliente - dispensa o cliente da caixa */
	void DispensaCliente (FILE *);
	
	/* ProcessaFila - atende ou dispensa clientes */
	void ProcessaFila (FILE *);
	
	/* VerNumAtendidos - vê o número de atendidos */
	int VerNumAtendidos ();
	
	/* VerSomaTemposEspera - vê a soma dos tempos de espera */
	int VerSomaTemposEspera ();
	
	/* VerSomaComprimentos - vê a soma dos comprimentos da fila */
	int VerSomaComprimentos ();

};

#endif


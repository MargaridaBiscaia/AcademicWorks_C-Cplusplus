#ifndef TADAG
#define TADAG
#define MAXN 300

#include "pessoa.h"
#include "TADLista.h"

// Definição da estrutura de grafo (implementação com matriz de adjacências)
typedef struct grafo{
	int Adj[MAXN][MAXN];
	int numNos;
	Pessoa nos[MAXN];
}Grafo;

/* Criar Grafo
 * → G, ponteiro indefinido
 * ← G=NULL
 */
void criarGrafo(Grafo *);

/* Vazio?
 * → G, grafo
 * ← 1 se G=NULL, 0 se G!=NULL
 */
int vazio(Grafo);

/* Inserir Pessoa
 * → G, ponteiro para grafo; p, Pessoa
 * ← G alterado
 */
void inserirPessoa(Grafo *,Pessoa);

/* Retirar Pessoa
 * → G, ponteiro para grafo; p, Pessoa
 * ← G alterado
 */
void retirarPessoa(Grafo *,Pessoa);

/* Inserir relação
 * → G, ponteiro para grafo; porigem, Pessoa; pdestino, Pessoa; relacao, carater
 * ← G alterado
 */
void inserirRelacao(Grafo *,Pessoa,Pessoa,char);

/* Retirar relação
 * → G, ponteiro para grafo; porigem, Pessoa; pdestino, Pessoa
 * ← G alterado
 */
void retirarRelacao(Grafo *,Pessoa,Pessoa);

/* Editar Pessoa
 * → p, ponteiro para Pessoa; modificacao, carater
 * ← p alterado
 */
void editarPessoa(Pessoa *,char);

/* Pesquisa de Progenitores
 * → G, grafo; p, pessoa
 * ← lista de progenitores de p
 */
Lista progenitores(Grafo,Pessoa);

/* Pesquisa de Irmãos
 * → G, grafo; p, pessoa
 * ← lista de irmãos de p
 */
Lista irmaos(Grafo,Pessoa);

/* Pesquisa de Família
 * → G, grafo; p, pessoa
 * ← lista da família de p
 */
Lista familia(Grafo,Pessoa);

/* Pesquisa de Ancestrais
 * → G, grafo; p, pessoa
 * ← lista de ancestrais de p
 */
Lista ancestrais(Grafo,Pessoa);

#endif

/* Projeto realizado por Margarida Biscaia Caleiras, 2019217343
 * Programa que lê dois ficheiros com dados de uma família e que constrói
 * a sua árvore genealógica, permitindo a modificação e pesquisa na mesma
 * → dois ficheiros com os dados de uma família e as suas relações interpessoais
 * ← árvore genealógica escrita em formato csv nos ficheiros de entrada
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "TADAG.h"
#include "TADLista.h"
#include "auxiliares.h"
#include "pessoa.h"

int main(){
	FILE *f1,*f2;
	Grafo G;
	int num1,num2;
	char op,char1;
	
	//Criar AG
	criarGrafo(&G);
	
	//Leitura do ficheiro pessoa.csv e inserção das pessoas na AG
	f1=fopen("pessoas.csv","r");
	if ((f1=fopen("pessoas.csv","r"))==NULL) {
		printf("Não foi possível abrir, para leitura, o ficheiro: «pessoas.csv».\n");
	}
	else {
		lerDados(f1,&G);	
		fclose(f1);
	}
	
	//Leitura do ficheiro relacoes.csv e inserção das relações na AG
	f2=fopen("relacoes.csv","r");
	if((f2=fopen("relacoes.csv","r"))==NULL) {
		printf("Não foi possível abrir, para leitura, o ficheiro: «relacoes.csv».\n");
	}
	else{
		lerRelacoes(f2,&G);
		fclose(f2);
	}	
	
	//Operações de modificação da AG
	printf("\tManipulação da Árvore Genealógica\n");
	if(!vazio(G)){
		printf("Pessoas na Árvore Genealógica:\n");
		escreverNomes(G);
	}
	printf("\nOperações: \n1.Editar Pessoa\n2.Inserir Pessoa\n3.Inserir Relação\n4.Remover Pessoa\n5.Remover Relação\n6.Sair\n");
	do{
		printf("\nQue operação deseja realizar? ");
		scanf(" %c",&op);
		
		switch(op){
			case '1':
				//Editar pessoa
				printf("Quem deseja editar? ");
				scanf("%d",&num1);
				printf("O que deseja editar? (N-nome,n-nascimento,f-falecimento): ");
				scanf(" %c",&char1);
			
				editarPessoa(&G.nos[num1],char1);
				printf("\nPessoas na Árvore Genealógica:\n");
				escreverNomes(G);
				break;
			case '2':
				//Inserir pessoa
				printf("Nome: ");
				limpa_stdin();
				fgets(G.nos[G.numNos].nome,MAX,stdin);
				G.nos[G.numNos].nome[strcspn(G.nos[G.numNos].nome,"\n")]='\0';
				printf("Data de nascimento (ano mes dia): ");
				scanf("%d %d %d",&G.nos[G.numNos].nascimento.ano,&G.nos[G.numNos].nascimento.mes,&G.nos[G.numNos].nascimento.dia);
				printf("Data de falecimento (ano mes dia): ");
				scanf("%d %d %d",&G.nos[G.numNos].falecimento.ano,&G.nos[G.numNos].falecimento.mes,&G.nos[G.numNos].falecimento.dia);
				
				inserirPessoa(&G,G.nos[G.numNos]);
				printf("\nPessoas na Árvore Genealógica:\n");
				escreverNomes(G);
				break;
			case '3':
				//Inserir relação
				printf("Que relação deseja inserir? (P-progenitor,C-conjuge): ");
				scanf(" %c",&char1);
				printf("Entre quem deseja iserir a relação? ");
				if(char1=='P'){
					printf("(Coloque o progenitor em primeiro lugar): ");
				}
				scanf("%d %d",&num1,&num2);
					
				inserirRelacao(&G,G.nos[num1],G.nos[num2],char1);
				break;
			case '4':
				//Remover pessoa
				printf("Quem deseja remover? ");
				scanf("%d",&num1);
				
				retirarPessoa(&G,G.nos[num1]);
				printf("\nPessoas na Árvore Genealógica:\n");
				escreverNomes(G);
				break;
			case '5':
				//Remover relação
				printf("Entre quem deseja remover a relação? ");
				scanf("%d %d",&num1,&num2);
				
				retirarRelacao(&G,G.nos[num1],G.nos[num2]);
				break;
			case '6':
				break;
		}	
	}while(op!='6');
	
	//Escrever os dados de cada pessoa no ficheiro pessoas.csv
	f1=fopen("pessoas.csv","w");
	if ((f1=fopen("pessoas.csv","w"))==NULL) {
		printf("Não foi possível abrir, para escrita, o ficheiro: «pessoas.csv».\n");
	}
	else{
		escreverDados(f1,G);	
		fclose(f1);
	}
	
	//Escrever as relações no ficheiro relacoes.csv
	f2=fopen("relacoes.csv","w");
	if((f1=fopen("relacoes.csv","w"))==NULL) {
		printf("Não foi possível abrir, para escrita, o ficheiro: «relacoes.csv».\n");
	}
	else{
		escreverRelacoes(f2,G);
		fclose(f2);
	}
	
	//Operações de pesquisa na AG
	printf("\n\tPesquisa na Árvore Genealógica\n");
	printf("Pessoas na Árvore Genealógica:\n");
	escreverNomes(G);
	printf("\nOperações: \n1.Irmãos\n2.Pais\n3.Família\n4.Ancestrais\n5.Sair\n");
	do{
		printf("\nQue operação deseja realizar? ");
		scanf(" %c",&op);
		
		if(op!='5'){
			printf("Em quem deseja pesquisar? ");
			scanf("%d",&num1);
		}
		
		switch(op){
			case '1':
				//Pesquisa de irmãos
				if(!vaziaLista(irmaos(G,G.nos[num1]))){
					printf("Os irmãos de %s são:\n",G.nos[num1].nome);
					escreverLista(irmaos(G,G.nos[num1]));
				}
				else{
					printf("%s não tem irmãos.\n",G.nos[num1].nome);
				}
				break;
			case '2':
				//Pesquisa de progenitores
				if(!vaziaLista(progenitores(G,G.nos[num1]))){
					printf("Os pais de %s são:\n",G.nos[num1].nome);
					escreverLista(progenitores(G,G.nos[num1]));
				}
				else{
					printf("%s não tem pais.\n",G.nos[num1].nome);
				}
				break;
			case '3':
				//Pesquisa de família
				printf("A família de %s é:\n",G.nos[num1].nome);
				escreverLista(familia(G,G.nos[num1]));
				break;
			case '4':
				//Pesquisa de ancestrais
				if(!vaziaLista(ancestrais(G,G.nos[num1]))){
					printf("Os ancestrais de %s são:\n",G.nos[num1].nome);
					escreverLista(ancestrais(G,G.nos[num1]));
				}
				else{
					printf("%s não tem ancestrais.\n",G.nos[num1].nome);
				}
				break;
			case '5':
				break;
		}	
	}while(op!='5');
	
	return 0;
}

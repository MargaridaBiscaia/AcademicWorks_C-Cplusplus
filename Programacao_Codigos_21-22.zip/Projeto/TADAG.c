#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "TADAG.h"
#include "auxiliares.h"

// Criar Grafo
void criarGrafo(Grafo *G){
	int i,j;
	
	for(i=0;i<MAXN;i++){
		for(j=0;j<MAXN;j++){
			G->Adj[i][j]=0;
		}
	}
	G->numNos=0;
}

// Vazio?
int vazio(Grafo G){
	return (G.numNos==0);
}

// Inserir Pessoa
void inserirPessoa(Grafo *G,Pessoa p){
	G->nos[G->numNos]=p;
	G->numNos++;
}

// Retirar Pessoa
void retirarPessoa(Grafo *G,Pessoa p){
	int i,j,valor=0;
	
	while(strcmp(G->nos[valor].nome,p.nome)!=0){
		valor++;
	} // Determinar a posição de p no vetor nós
	
	for(i=0; i<G->numNos; i++){
		for(j=valor; j<G->numNos-1; j++){
			G->Adj[i][j]=G->Adj[i][j+1];
		}
	}
	
	for(i=valor;i<G->numNos-1; i++){
		G->nos[i]=G->nos[i+1]; // Retirar p do vetor nos
		for(j=0; j<G->numNos-1; j++){
			G->Adj[i][j]=G->Adj[i+1][j];
		}
	} 
	
	G->numNos --;
}

// Inserir relação
void inserirRelacao(Grafo *G,Pessoa porigem,Pessoa pdestino,char relacao){
	int origem=0,destino=0;
	
	while(strcmp(G->nos[origem].nome,porigem.nome)!=0){
		origem++;
	} // Determinar a posição de porigem no vetor nós
	
	while(strcmp(G->nos[destino].nome,pdestino.nome)!=0){
		destino++;
	} // Determinar a posição de pdestino no vetor nós
	
	if(relacao=='P'){
		G->Adj[origem][destino]=1;
	}
	else{
		G->Adj[origem][destino]=2;
		G->Adj[destino][origem]=2;
	}
}

// Retirar relação	
void retirarRelacao(Grafo *G,Pessoa porigem,Pessoa pdestino){
	int origem=0,destino=0;
	
	while(strcmp(G->nos[origem].nome,porigem.nome)!=0){
		origem++;
	} // Determinar a posição de porigem no vetor nós
	
	while(strcmp(G->nos[destino].nome,pdestino.nome)!=0){
		destino++;
	} // Determinar a posição de pdestino no vetor nós
	
	G->Adj[origem][destino]=0;
	if(G->Adj[origem][destino]==2){
		G->Adj[destino][origem]=0;
	}
}

// Editar Pessoa
void editarPessoa(Pessoa *p,char modificacao){
	if (modificacao=='N'){
		printf("Novo nome: ");
		limpa_stdin();
		fgets(p->nome,MAX,stdin);
		p->nome[strcspn(p->nome,"\n")]='\0';
	}
	else if (modificacao=='n'){
		printf("Nova data de nascimento (ano mes dia): ");
		scanf("%d %d %d",&p->nascimento.ano,&p->nascimento.mes,&p->nascimento.dia);
	}
	else if (modificacao=='f'){
		printf("Nova data de falecimento (ano mes dia): ");
		scanf("%d %d %d",&p->falecimento.ano,&p->falecimento.mes,&p->falecimento.dia);
	}
}

// Pesquisa de Progenitores
Lista progenitores(Grafo G,Pessoa p){
	Lista listaProgenitores;
	int i,valor=0;
	
	criarLista(&listaProgenitores);
	
	while(strcmp(G.nos[valor].nome,p.nome)!=0){
		valor++;
	} // Determinar a posição de p no vetor nós
	
	for(i=0;i<G.numNos;i++){
		if(G.Adj[i][valor]==1){
			inserirN(&listaProgenitores,G.nos[i],1);
		} // Inserir as pessoas que tenham 1 na coluna de p
	}
	return listaProgenitores;
}

// Pesquisa de Irmãos
Lista irmaos(Grafo G,Pessoa p){
	Lista listaIrmaos;
	int i=0,j,valor=0;
	
	criarLista(&listaIrmaos);
	
	while(strcmp(G.nos[valor].nome,p.nome)!=0){
		valor++;
	} // Determinar a posição de p no vetor nós
	
	while(G.Adj[i][valor]!=1 && i<G.numNos){
		i++;
	} // Determinar um progenitor de p

	for(j=0;j<G.numNos;j++){
		if(G.Adj[i][j]==1 && j!=valor){
				inserirN(&listaIrmaos,G.nos[j],1);
		} // Inserir todas as pessoas que têm o mesmo progenitor de p
	}
	return listaIrmaos;
}

// Pesquisa de família
Lista familia(Grafo G,Pessoa p){
	Lista listaFamilia;
	int valor=0,i;
	
	criarLista(&listaFamilia);
	
	while(strcmp(G.nos[valor].nome,p.nome)!=0){
		valor++;
	} // Determinar a posição de p no vetor nós
	
	for(i=0;i<G.numNos;i++){
		if(i!=valor){
			inserirN(&listaFamilia,G.nos[i],1); // Inserir todas as pessoas do vetor nós, exceto p
		}
	}
	return listaFamilia;
}

/* Auxiliar de ancestrais
 * Esta função auxiliar é uma função definida por recorrência utilizada 
 * para determinar os ancestrais de uma pessoa. Não pertence à TADAG.
 * → G, grafo; p, Pessoa; listaAncestrais, ponteiro para lista
 * ← listaAncestrais alterada
 */
void ancestraisAux(Grafo G,Pessoa p, Lista *listaAncestrais){
	int i;
	if(!vaziaLista(progenitores(G,p))){ // Condição de paragem
		for(i=1;i<=comprimento(progenitores(G,p));i++){
			inserirN(&(*listaAncestrais),verN(progenitores(G,p),i),1); // Inserir pessoa na posição i da lista de progenitores na lista de ancestrais
			ancestraisAux(G,verN(progenitores(G,p),i),&(*listaAncestrais)); // Pesquisar ancestrais da pessoa na posição i da lista de progenitores
		}
	}
}

// Pesquisa de ancestrais
Lista ancestrais(Grafo G,Pessoa p){
	Lista listaAncestrais;
	
	criarLista(&listaAncestrais);
	
	ancestraisAux(G,p,&listaAncestrais); // Função auxiliar recorrente
	
	return listaAncestrais;
}

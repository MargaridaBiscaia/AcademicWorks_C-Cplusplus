#include <stdlib.h>
#include <stdio.h>

#include "TADLista.h"

// Criar lista vazia
void criarLista(Lista *lista) {
	(*lista)=NULL;
}

// Vazia?
int vaziaLista(Lista lista){
	return(lista==NULL);
}

// Inserir elemento
void inserirN(Lista *lista, Pessoa elemento,int posicao) {
	Lista ant=NULL, aux=(*lista);
	Lista novo=(Lista)malloc(sizeof(No));
	int i=1;
	
	novo->elem=elemento;
	
	while(i<posicao){
		i++;
		ant=aux;
		aux=aux->prox;	
	}
	
	if(ant==NULL){
		novo->prox=aux;
		(*lista)=novo;
	}
	else{
		novo->prox=aux;
		ant->prox=novo;
	}
}
// Retirar elemento
void retirarN (Lista *lista,int posicao) {
	Lista ant=NULL, aux=(*lista);
	int i=1;
	
	while(i<posicao){
		i++;
		ant=aux;
		aux=aux->prox;
	}
	
	if(ant==NULL){
		(*lista)=aux->prox;
		free(aux);
	}
	else{
		ant->prox=aux->prox;
		free(aux);
	}
}

// Ver elemento
Pessoa verN(Lista lista,int posicao){
	int i=1;
	
	while(i<posicao){
		i++;
		lista=lista->prox;
	}
	
	return (lista->elem);
}

// Determinar comprimento da lista
int comprimento (Lista lista){
	int cmp=0;
	
	while (lista!=NULL){
		cmp++;
		lista=lista->prox;
	}
	return (cmp);
}

// Escrever lista
void escreverLista (Lista lista){
	while(lista!=NULL){
		printf("%s\n",lista->elem.nome);
		lista=lista->prox;
	}
}
		

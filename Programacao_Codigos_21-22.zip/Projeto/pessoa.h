#ifndef PESSOA
#define PESSOA
#define MAX 100

// Definição da estrutura Data
typedef struct data {
	int ano;
	int mes;
	int dia;
}Data;

// Definição da estrutura Pessoa
typedef struct pessoa {
	char nome[MAX];
	Data nascimento;
	Data falecimento;
}Pessoa;

#endif

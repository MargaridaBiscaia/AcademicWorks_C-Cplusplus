#ifndef AUXILIARES
#define AUXILIARES

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "pessoa.h"
#include "TADAG.h"

/* Obter um Campo
 * Dado uma linha de texto em formato CSV (string) vai obter um dos
 * seus campos.  1 <= num <= número de campos numa linha (caso
 * contrário devolve a string vazia).
 * → linha, num - linha de texto e número de campo a obter
 * ← campo (string)
 */
char* obtemCampo(char *,int);

/* Limpa_stdin
 * Retira carateres supérfulos do canal de entrada
 */
void limpa_stdin(void);

/* Ler Dados de um ficheiro
 * → f, ponteiro para ficheiro; G, grafo
 * ← G alterado
 */
void lerDados(FILE *,Grafo *);

/* Ler Relações de um ficheiro
 * → f, ponteiro para ficheiro; G, grafo
 * ← G alterado
 */
void lerRelacoes(FILE *,Grafo *);

/* Escrever Dados de um ficheiro
 * → f, ponteiro para ficheiro; G, grafo
 * ← f com dados de uma família (nome, data de nascimento, data de falecimento)
 */
void escreverDados(FILE *,Grafo);

/* Escrever Relações de um ficheiro
 * → f, ponteiro para ficheiro; G, grafo
 * ← f com a informação das relações de uma família (dois nomes e uma relação)
 */
void escreverRelacoes(FILE *,Grafo);

/* Escrever Nomes
 * → G, grafo
 * ← dados dos elementos do vetor nos de G
 */
void escreverNomes(Grafo);
	
#endif

#ifndef TADLISTA
#define TADLISTA

#include "pessoa.h"

// Definição da estrutra de lista simplesmente ligada, de pessoas
typedef struct no {
	Pessoa elem;
	struct no* prox;
}No;

typedef No *Lista;

/* Criar lista vazia
 * → lista, ponteiro indefinido
 * ← lista=NULL
 */
void criarLista(Lista *);

/* Vazia?
 * → lista
 * ← 0 se lista!=NULL, 1 se lista==NULL
 */
int vaziaLista(Lista);

/* Inserir elemento
 * → lista, ponteiro para lista; p, Pessoa; posicao, inteiro
 * ← lista alterada
 */
void inserirN(Lista *,Pessoa,int);

/* Retirar elemento
 * → lista, ponteiro para lista; posicao, inteiro
 * ← lista alterada
 */
void retirarN (Lista *,int);

/* Ver elemento
 * → lista; posicao, inteiro
 * ← p, Pessoa, na posição "posicao" da lista
 */
Pessoa verN(Lista,int);

/* Determinar comprimento da lista
 * → lista
 * ← comprimento da lista
 */
int comprimento(Lista);

/* Escrever lista
 * → lista
 * ← nome dos elementos da lista
 */
void escreverLista(Lista);

#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "auxiliares.h"

// Obtem um campo
char* obtemCampo(char* linha,int num) {
  char* campo;

  campo=strtok(linha,";");
  
  while(num>1 && campo!=NULL){
    //;campo=strtok(NULL,";\n")){
    num=num-1;
    campo=strtok(NULL,";\n");
  }
  return campo;
}

// Limpa_stdin
void limpa_stdin(void){
	int c;
	
	do{
		c=getchar();
	}while (c!='\n' && c!= EOF);
}

// Ler dados e inserir na AB
void lerDados(FILE *f,Grafo *G){
	char linha[1024],*tmp;
	int i=0;
	
	while(fgets(linha,1024,f)){
		tmp=strdup(linha);
		strcpy(G->nos[i].nome,obtemCampo(tmp,1));
		  
		tmp=strdup(linha);
		G->nos[i].nascimento.ano=atoi(obtemCampo(tmp,2));
			  
		tmp=strdup(linha);
		G->nos[i].nascimento.mes=atoi(obtemCampo(tmp,3));
			  
		tmp=strdup(linha);
		G->nos[i].nascimento.dia=atoi(obtemCampo(tmp,4));
			  
		tmp=strdup(linha);
		G->nos[i].falecimento.ano=atoi(obtemCampo(tmp,5));
			  
		tmp=strdup(linha);
		G->nos[i].falecimento.mes=atoi(obtemCampo(tmp,6));
			  
		tmp=strdup(linha);
		G->nos[i].falecimento.dia=atoi(obtemCampo(tmp,7));
			  
		free(tmp);
			
		inserirPessoa(&(*G),G->nos[i]);
		i++;
	}
}

// Ler relações e inserir na AB
void lerRelacoes(FILE *f,Grafo *G){
	char linha[1024],campo1[128],campo2[128],campo3[128],*tmp;
	int num1,num2;
	
	while(fgets(linha,1024,f)){
		tmp=strdup(linha);
		strcpy(campo1,obtemCampo(tmp,1));
			
		tmp=strdup(linha);
		strcpy(campo2,obtemCampo(tmp,2));
			
		tmp=strdup(linha);
		strcpy(campo3,obtemCampo(tmp,3));
			
		num1=0;
		while(strcmp(G->nos[num1].nome,campo1)!=0){
			num1++;
		} // Associar o campo1 a uma pessoa no vetor nos
		num2=0;
		while(strcmp(G->nos[num2].nome,campo2)!=0){
			num2++;
		} // Associar o campo2 a uma pessoa no vetor nos
		free(tmp);	
			
		inserirRelacao(&(*G),G->nos[num1],G->nos[num2],campo3[0]);		
	}
}

// Escrever dados
void escreverDados(FILE *f,Grafo G){
	int i;
	
	for(i=0;i<G.numNos;i++){
		fprintf(f,"%s;",G.nos[i].nome);
		fprintf(f,"%d;",G.nos[i].nascimento.ano);
		fprintf(f,"%d;",G.nos[i].nascimento.mes);
		fprintf(f,"%d;",G.nos[i].nascimento.dia);
		fprintf(f,"%d;",G.nos[i].falecimento.ano);
		fprintf(f,"%d;",G.nos[i].falecimento.mes);
		fprintf(f,"%d\n",G.nos[i].falecimento.dia);
	}
}

// Escrever relações
void escreverRelacoes(FILE *f,Grafo G){	
	int i,j;
		
	for(i=0;i<G.numNos;i++){
		for(j=0;j<G.numNos;j++){
			if(G.Adj[i][j]==1){
				fprintf(f,"%s;%s;P\n",G.nos[i].nome,G.nos[j].nome);
			}
			else if(G.Adj[i][j]==2){
				fprintf(f,"%s;%s;C\n",G.nos[i].nome,G.nos[j].nome);
			}
		}
	}
}
	
// Escrever nomes
void escreverNomes(Grafo G){
	int i;
	
	for(i=0;i<G.numNos;i++){
		printf("%d-%s, %d/%d/%d, %d/%d/%d\n",i,G.nos[i].nome,G.nos[i].nascimento.ano,G.nos[i].nascimento.mes,G.nos[i].nascimento.dia,G.nos[i].falecimento.ano,G.nos[i].falecimento.mes,G.nos[i].falecimento.dia); 
	}	
}		

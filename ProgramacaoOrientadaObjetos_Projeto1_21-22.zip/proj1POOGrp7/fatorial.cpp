#include <iostream>
#include "fatorial.hpp"

using namespace std;

Igd fatorial (Igd n){
	Igd zero, um;
	
	// Criar Igd's 0 e 1
	zero.criar();
	um.criar();
	
	zero.conversaoIntIgd(0);
	um.conversaoIntIgd(1);
	
	// Implementação recursiva
	if (n.comparacao(zero) == 0){
		return um;
	}
	else {
		return (n.multiplicacao(fatorial(n.subtracao(um))));
	}	
}

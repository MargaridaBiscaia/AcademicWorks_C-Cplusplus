#include <iostream>
#include <cstdlib>
#include <cstring>
#include "igd.hpp"

using namespace std;

//Construtor
Igd::Igd (){
	elems = new unsigned char[MAXN];
	dim =0;
}

//Construtor por cópia
Igd::Igd (const Igd& v){
	int i;
	dim = v.dim;
	elems = new unsigned char[dim];
		
	for(i=0;i<dim;i++){
		elems[i]=v.elems[i];
	}
}

//Destrutor
Igd::~Igd (){
	dim=0;
	delete [] elems;
}

//Criar
void Igd::criar (){
	int i;

	dim = 0;
	elems = new unsigned char[MAXN]; //Allocar memória

	for(i=0;i<=MAXN;i++){
		elems[i]=0; //Inicializar o vetor a zero
	}
}

//Ler
void Igd::lerIgd (){
	char str[MAXN];
	int i,comp;
	
	cout << "Introduza um inteiro: ";
	cin >> str;
	
	comp=strlen(str); //Calcular o número de algarismos do inteiro
	
	for(i=0; i<comp; i++){
		elems[i]=str[i]-'0'; //Copiar os valores da string para um Igd, com utilização da tabela ASCII
	}
	dim = strlen(str);
}

//Escrever
void Igd::escreverIgd(){
	int i;
	
	if(elems[0]=='-'){ //Se o número for negativo, escrever -
		cout << elems[0];
		for(i=1; i<dim; i++){
			cout << (int)elems[i];
		}
	}
	else{
		for(i=0; i<dim; i++){
			cout << (int)elems[i];
		}
	}
	cout << endl;
}

//Comparação
int Igd::comparacao (Igd v) {
	int i;
	
	//Se a dimensao do vetor 1 for maior que a dimensao do vetor 2 devolve 1
	if(dim>v.dim){
		return (1);
	}
	//Se a dimensao do vetor 1 for menor que a dimensao do vetor 2 devolve -1
	if(dim<v.dim){
		return (-1); 
	}
	if(dim==v.dim){ // Se a dimensao do vetor 1 for igual à dimensao do vetor 2
		for(i=0; i<dim; i++){ // Percorrer os vetores
			
			if(elems[i]>v.elems[i]){ //Se encontrar um valor do vetor 1 maior do que o vetor 2, devolve 1
				return (1);
				break;
			}
			if(elems[i]<v.elems[i]){ //Se encontrar um valor do vetor 1 menor do que o vetor 2, devolve -1
				return (-1);
				break;
			}
			if((elems[i]==v.elems[i]) && (i==dim-1)){ // Se, no fim do ciclo, o vetor 1 for igual ao vetor 2, devolve 0
				return (0);
			}
		}
	}
		
}

//ConversãoIntIgd
void Igd::conversaoIntIgd(long int m){
	int i;
	char str[MAXN];
	
	sprintf(str,"%d",m);
	
	for(i=0; i<strlen(str); i++){ //Copiar os valores da string para um Igd, com utilização da tabela ASCII
		elems[i]=str[i]-'0';
	}
	dim = strlen(str);
}

//Simétrico
void Igd::simetrico (){
	int i;
	
	if(elems[0]=='-'){ //Se o número for negativo
		//Andar com os elementos todos para trás
		for(i=0; i<dim-1;i++){
			elems[i]=elems[i+1];
		}
		dim--;
	}
	else{ //Se o número for positivo
		//Andar com os elementos todos para a frente
		for(i=dim-1;i>=0;i--){
			elems[i+1]=elems[i];
		}
		elems[0]='-'; //Primeiro elemento passa a negativo
		dim++;
	}
}

//Adição
Igd Igd::adicao (Igd v){
	int i,j;
	Igd res,aux1;
	
	res.criar();
	aux1.criar();
	
	for(i=0;i<dim;i++){
		aux1.elems[i]=elems[i];
	}
	aux1.dim=dim;
	
	//Colocar os vetores com a mesma dimensão, igualando os algarismos /
	// das unidades , dezenas, ... 
	// exemplo: [5] -> [0 0 5]
	if(aux1.dim>v.dim){
		i=aux1.dim-1;
		j=v.dim-1;
		
		//Copiar os elementos para o fim do novo vetor
		// exemplo: [5] -> [5 0 5]
		while(j!=-1){
			v.elems[i]=v.elems[j];
			//Colocar a 0 o valor inicial exemplo: [5 0 5] -> [0 0 5]
			i--;
			j--;
		}
		
		//Colocar a 0 os restantes valores iniciais
		// exemplo: [5 0 5] -> [0 0 5]
		for(i=0; i<=(aux1.dim-v.dim-1); i++){v.elems[i]=0;}
		
		v.dim=aux1.dim;
	}
	else if (aux1.dim<v.dim){
		i=v.dim-1;
		j=aux1.dim-1;
		
		//Copiar os elementos para o fim do novo vetor
		while(j!=-1){
			aux1.elems[i]=aux1.elems[j];
			i--;
			j--;
		}
		
		//Colocar a 0 os restantes valores iniciais
		for(i=0; i<=(v.dim-aux1.dim-1); i++){aux1.elems[i]=0;}
		aux1.dim=v.dim;
		
	} 
	
	//Somar componente a componente
	for(i=(aux1.dim-1); i>=0; i--){
		res.elems[i]=res.elems[i]+aux1.elems[i]+v.elems[i];
		
		//Transportes
		if(res.elems[i]>=10 && i!=0){
			res.elems[i-1]=res.elems[i]/10;
			res.elems[i]=res.elems[i]%10;
		}
	}
	
	res.dim=aux1.dim;

	//Se o primeiro elemento do resultado for >=10, simplificar para Igd
	if(res.elems[0]>=10){
		i=res.dim-1;
		
		while(i!=0){
			res.elems[i+1]=res.elems[i];
			i--;
		}
		
		res.elems[1]=res.elems[0]%10;
		res.elems[0]=res.elems[0]/10;
		res.dim++;
	}
	
	return(res);
}

//Subtração
Igd Igd::subtracao (Igd v){
	int i,j;
	Igd res,aux1;
	
	res.criar();
	aux1.criar();
	
	for(i=0;i<dim;i++){
		aux1.elems[i]=elems[i];
	}
	aux1.dim=dim;
	
	if(comparacao(v)==0){ //Se os números forem iguais
		res.elems[0]=0;
		res.dim=1;
	}
	else{
		//Colocar os vetores com a mesma dimensão, igualando os algarismos /
		// das unidades , dezenas, ... 
		// exemplo: [5] -> [0 0 5]
		if(aux1.dim>v.dim){
			i=aux1.dim-1;
			j=v.dim-1;
			
			//Copiar os elementos para o fim do novo vetor
			// exemplo: [5] -> [5 0 5]
			while(j!=-1){
				v.elems[i]=v.elems[j];
				i--;
				j--;
			}
			
			//Colocar a 0 os restantes valores iniciais
			// exemplo: [5 0 5] -> [0 0 5]
			for(i=0; i<=(aux1.dim-v.dim-1); i++){v.elems[i]=0;}
			
			v.dim=aux1.dim;
		}
		else if (aux1.dim<v.dim){
			i=v.dim-1;
			j=aux1.dim-1;
			
			//Copiar os elementos para o fim do novo vetor
			while(j!=-1){
				aux1.elems[i]=aux1.elems[j];
				i--;
				j--;
			}
			
			//Colocar a 0 os restantes valores iniciais
			for(i=0; i<=(v.dim-aux1.dim-1); i++){aux1.elems[i]=0;}
			
			aux1.dim=v.dim;
		}
		
		//Subtração componente a componente
		if(comparacao(v)==1){
			for(i=aux1.dim-1;i>=0;i--){
				if(aux1.elems[i]>=v.elems[i]){
					res.elems[i]=aux1.elems[i]-v.elems[i];
				}
				else{
					res.elems[i]= (10 + aux1.elems[i]) - v.elems[i];
					if(i!=0){
						v.elems[i-1]= v.elems[i-1]+1; //Transportes
					}
				}
			}
			res.dim=aux1.dim;
		}
		else if (comparacao(v)==-1){
			for(i=v.dim-1;i>=0;i--){
				if(v.elems[i]>=aux1.elems[i]){
					res.elems[i]=v.elems[i]-aux1.elems[i];
				}
				else{
					res.elems[i]= 10 + v.elems[i] - aux1.elems[i];
					if(i!=0){
						aux1.elems[i-1]= aux1.elems[i-1]+1; //Transportes
					}
				}
			}
			res.dim=v.dim;
		}
		
		//Se tiver 0's no início
		while (res.elems[0]==0){
			for(i=0; i< res.dim-1;i++){
				res.elems[i]=res.elems[i+1];
			}
			res.dim--;
		}
	}
	
	return (res);
}

//Multiplicação
Igd Igd::multiplicacao (Igd v){
	int i,j,k;
	Igd res,aux,aux1;
	
	res.criar();
	aux.criar();
	aux1.criar();
	
	
	
	for(i=0;i<dim;i++){
		aux1.elems[i]=elems[i];
	}
	aux1.dim=dim;
	
	j=v.dim-1;
	
	while(j!=-1){
		aux.dim=0;
		
		if(res.dim == 0){ //Primeira iteração
			aux.elems[0]=0;
			aux.dim++;
		}
		
		for(k=0;k<res.dim;k++){ // Tomar aux = res
			aux.elems[k]=res.elems[k];
			res.elems[k]=0;
			aux.dim++;
		}
		
		//Multiplicacao da componente j de v2 pela componente i de v1
		for(i=aux1.dim-1;i>=0;i--){
			res.elems[i]=res.elems[i] + (aux1.elems[i]*v.elems[j]);
			
			//Transportes
			if(res.elems[i]>=10 && i!=0){
				res.elems[i-1]=res.elems[i]/10;
				res.elems[i]=res.elems[i]%10;
			}
		}
		res.dim=aux1.dim;
		
		//Se o primeiro elemento do resultado for >=10, simplificar
		if(res.elems[0]>=10){
			i=res.dim-1;
			
			while(i!=0){
				res.elems[i+1]=res.elems[i];
				i--;
			}
			
			res.elems[1]=res.elems[0]%10;
			res.elems[0]=res.elems[0]/10;
			res.dim++;
		}
		
		//Começar outra iteração
		aux1.elems[aux1.dim]=0;
		aux1.dim++;
		
		v.dim--;
		
		// Tomar aux2 = res.adicao(aux)
		Igd aux2;
		aux2.criar();
		aux2.dim = (res.adicao(aux)).dim;
		
		for(k=0;k<aux2.dim;k++){
			aux2.elems[k]=(res.adicao(aux)).elems[k];
		}
		
		// Tomar res = res+aux2
		for(k=0;k<aux2.dim;k++){
			res.elems[k]=aux2.elems[k];
		}
		res.dim=aux2.dim;
		
		j=v.dim-1;
	}
	
	if(res.elems[0]==0){
		Igd zero;
		zero.criar();
	
		zero.conversaoIntIgd(0);
	
		return (zero);
	}
	
	return(res);

}

//DivisãoInteira
Igd Igd::divisaoInteira (Igd v){
	Igd quociente,um,aux1;
	int i;
	
	quociente.criar();
	quociente.conversaoIntIgd(1);
	
	um.criar();
	um.conversaoIntIgd(1);
	
	aux1.criar();
	
	for(i=0;i<dim;i++){
		aux1.elems[i]=elems[i];
	}
	aux1.dim=dim;
	
	if( comparacao(v) == -1){ //Se v1<v2, v1/v2 = 0
		Igd zero;
		zero.criar();
		zero.conversaoIntIgd(0);
		
		return (zero);
	}
	
	if ( v.comparacao(um) == 0 ){
		return (aux1);
	}
	
	//Enquanto quociente*v2 < v1, fazer quociente+1
	while( comparacao(quociente.multiplicacao(v)) == 1){
		quociente.dim = (quociente.adicao(um)).dim;
		for(i=0;i<quociente.dim;i++){
			quociente.elems[i]=(quociente.adicao(um)).elems[i];
		}
	}
	
	//Se quociente*v2 = v1, devolve quociente
	if( comparacao(quociente.multiplicacao(v)) == 0){
		return (quociente);
	}
	//Se quociente*v2 > v1, devolve quociente-1
	else{
		return (quociente.subtracao(um));
	}
}

//RestoDaDivisãoInteira	
Igd Igd::restoDaDivisaoInteira (Igd v){
	//Devolve v1 - divisaoInteira * v2 
	return( subtracao(divisaoInteira(v).multiplicacao(v))  );
}

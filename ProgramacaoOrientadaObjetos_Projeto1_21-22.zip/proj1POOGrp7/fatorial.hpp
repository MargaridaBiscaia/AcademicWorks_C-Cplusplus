#ifndef FATORIAL
#define FATORIAL

#include "igd.hpp"

/*
 * fatorial - calcular fatorial de um Igd
 * -> n, Igd
 * <- n!, Igd
 */ 
Igd fatorial (Igd);

#endif

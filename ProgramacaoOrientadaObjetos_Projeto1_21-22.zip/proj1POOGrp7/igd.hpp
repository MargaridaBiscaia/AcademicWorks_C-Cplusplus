/**	Classe IGD (Inteiro de Grande dimensão) de unsigned char  **/

#ifndef IGD
#define IGD

#define MAXN 500

class Igd {
private:
	//Definição do vetor de unsigned char
	int dim;
	unsigned char *elems;
	
public:
	//Construtor
	Igd ();
	
	//Construtor por cópia
	Igd (const Igd&); 

	//Destrutor
	~Igd ();

	//Manipuladores
	
	/* 
	 * criar - allocar memória e inicializar o vetor a 0
	 * -> v1, Igd
	 * <- v1:Igd
	 */
	void criar ();
	
	/* lerIgd - ler um Igd
	 * -> str, string
	 * <- v1, Igd
	 */
	void lerIgd ();
	
		/* escreverIgd - escrever um Igd
	 * -> v1, Igd
	 * <- v1
	 */
	void escreverIgd ();
	
	/* comparacao - comparar dois Igd's
	 * -> v1,Igd, v2 Igd
	 * se v1 = v2, <- 0
	 * se v1 > v2, <- 1
	 * se v1 < v2, <- -1		
	 */
	int comparacao (Igd);
	
	/* conversaoIntIgd - converter um inteiro num Igd
	 * -> m, int
	 * <- v1, Igd
	 */ 
	void conversaoIntIgd (long int);
	
	/* simetrico - converter um Igd no seu simétrico
	 * -> v1, Igd
	 * <- -v1
	 */
	void simetrico ();
	
	/* adicao - somar dois Igd's
	 * -> v1, Igd, v2, Igd
	 * <- v1+v2
	 */
	Igd adicao (Igd);
	
	/* subtracao - subtrair dois Igd's
	 * -> v1, Igd, v2, Igd
	 * <- v1-v2
	 */
	Igd subtracao (Igd);
	
	/* multiplicacao - multiplicar dois Igd's
	 * -> v1, Igd, v2, Igd
	 * <- v1*v2
	 */
	Igd multiplicacao (Igd);
	
	/* divisaoInteira - divisão inteira de dois Igd's
	 * -> v1, Igd, v2, Igd
	 * <- v1/v2
	 */
	Igd divisaoInteira (Igd);
	
	/* restoDaDivisaoInteira - resto da divisão inteira de dois Igd's
	 * -> v1, Igd, v2, Igd
	 * <- v1%v2
	 */
	Igd restoDaDivisaoInteira (Igd); 
	
	/* fatorial - calcular o fatorial de um Igd
	 * -> v1, Igd
	 * <- v1!
	 */ 
	Igd fatorial (Igd);
};

#endif

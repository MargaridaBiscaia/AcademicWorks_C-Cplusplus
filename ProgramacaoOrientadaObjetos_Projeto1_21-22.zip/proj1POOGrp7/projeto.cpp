#include <iostream>
#include "fatorial.hpp"
#include "igd.hpp"

using namespace std;

int main(){
	Igd n,m,igd;
	
	cout << "\t Testar as operações elementares" << endl;
	
	//Criar e ler n
	n.criar();
	n.lerIgd();
	
	//Criar e ler m
	m.criar();
	m.lerIgd();
	
	//Operações elementares
	cout << "Adição: ";
	(n.adicao(m)).escreverIgd();
	
	cout << "Subtração: ";
	(n.subtracao(m)).escreverIgd();
	
	cout << "Multiplicação: ";
	(n.multiplicacao(m)).escreverIgd();

	cout << "Divisão: ";
	(n.divisaoInteira(m)).escreverIgd();

	cout << "Resto da Divisão: ";
	(n.restoDaDivisaoInteira(m)).escreverIgd();
	
	cout << "Simétrico: ";
	n.simetrico();
	n.escreverIgd();
	
	cout << endl << "\t Fatorial de um inteiro não negativo" << endl;
	
	//Criar e ler igd
	igd.criar();
	igd.lerIgd();
	
	//Fatorial
	cout << "Fatorial = ";
	(fatorial(igd)).escreverIgd();

	return 0;
}
